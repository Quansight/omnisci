#ifndef COMMANDDETERMINANT_H
#define COMMANDDETERMINANT_H

struct CmdDeterminant {};
struct RegexCmdDeterminant : public CmdDeterminant {};

#endif
