#ifndef CLIENTCONTEXT_H
#define CLIENTCONTEXT_H

#include "MetaClientContext.h"

using ClientContext = MetaClientContext<MapDClient&, TTransport&>;

#endif
