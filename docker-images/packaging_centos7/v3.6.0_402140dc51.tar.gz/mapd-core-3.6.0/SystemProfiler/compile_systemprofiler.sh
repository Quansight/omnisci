g++ -o system_profiler SystemProfiler.cpp -L/usr/local/lib -lhwloc -lboost_filesystem -lboost_system
